module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ({

/***/ "0G5g":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "23aj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "getStaticProps", function() { return /* binding */ getStaticProps; });
__webpack_require__.d(__webpack_exports__, "default", function() { return /* binding */ Home; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: ./components/BrandList.tsx
var BrandList = __webpack_require__("cSw2");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./components/Spacer.tsx


;
function Spacer(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    style: {
      height: props.height
    }
  });
}
;
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__("Aiso");
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);

// EXTERNAL MODULE: ./components/Menu.tsx
var Menu = __webpack_require__("OrhP");

// CONCATENATED MODULE: ./components/ImageBanner.tsx





const ImageBanner = props => {
  const image = 'https://images.autofun.co.id/file1/6582f12e06dc42d1b3cefe1004ee4f01_1920x500.jpg';
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "relative overflow-hidden",
    style: {
      height: 500
    },
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "absolute top-0  h-24 w-full flex flex-row justify-between z-20 p-5",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
        src: "https://www.autofun.co.id/dist/id/images/logo-white-id.09f26c.svg",
        layout: "intrinsic",
        objectFit: "contain",
        width: 180,
        height: 60,
        className: ""
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-white font-bold",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Menu["a" /* default */], {})
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
      layout: "fill",
      src: image,
      objectFit: "cover",
      className: "background-animate image-fit"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "absolute px-8 top-1/3 w-full  text-center h-auto text-6xl  font-bold text-white text-center",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "inline-block w-4/5 text-shadow",
        style: {
          lineHeight: '70px'
        },
        children: "Daftar Mobil yang Dapat Diskon Pajak Mulai April, Fortuner dan Kijang Innova Masuk Daftar"
      })
    })]
  });
};

/* harmony default export */ var components_ImageBanner = (ImageBanner);
// EXTERNAL MODULE: ./components/SearchBar.tsx
var SearchBar = __webpack_require__("BwRl");

// CONCATENATED MODULE: ./components/home/ImageBannerWithSearchBar.tsx





function ImageBannerWithSearchBar(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "relative",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(components_ImageBanner, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "absolute -bottom-12 text-center w-full",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "inline-block w-3/5",
        style: {
          height: 70
        },
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(SearchBar["a" /* default */], {
          border: "border-white",
          shadow: "shadow-xl"
        })
      })
    })]
  });
}
;
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__("z+8S");

// EXTERNAL MODULE: ./helpers/queries/carQuery.ts
var carQuery = __webpack_require__("aZWA");

// EXTERNAL MODULE: ./components/Cars.tsx
var Cars = __webpack_require__("ZKgy");

// CONCATENATED MODULE: ./components/home/TopCar.tsx






function TopCar({
  cars
}) {
  const [getByGroup, {
    data
  }] = Object(client_["useLazyQuery"])(client_["gql"]`${carQuery["a" /* default */].getByGroup()}`, {
    variables: {
      group: 'MOST_POPULAR'
    },
    fetchPolicy: "cache-first"
  });
  const {
    0: selectedCars,
    1: setSelectedcars
  } = Object(external_react_["useState"])(cars);
  Object(external_react_["useEffect"])(() => {
    if (data !== null && data !== void 0 && data.CarsByGroup) {
      setSelectedcars(data.CarsByGroup);
    }
  }, [data]);
  const categories = [{
    id: 0,
    name: 'Most Popular',
    const: 'MOST_POPULAR'
  }, {
    id: 1,
    name: 'Latest',
    const: 'LATEST'
  }, {
    id: 2,
    name: 'LCGC',
    const: 'LCGC'
  }, {
    id: 3,
    name: 'SUV',
    const: 'SUV'
  }, {
    id: 4,
    name: 'Sedan',
    const: 'Sedan'
  }, {
    id: 5,
    name: 'MVP',
    const: 'MVP'
  }, {
    id: 6,
    name: 'City Car',
    const: 'City_Car'
  }];
  const {
    0: selectedGroupId,
    1: setSelectedGroupId
  } = Object(external_react_["useState"])("MOST_POPULAR");

  const selectCategory = group => {
    setSelectedGroupId(group);
    getByGroup({
      variables: {
        group
      }
    }); // fetch(Api.cars.getAll + '/' + id).then(res => res.json()).then(data => {
    //     setSelectedcars(data);
    // });
  };

  const selected = "text-yellow-400";
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "w-full overflow-hidden",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "grid grid-cols-2 md:grid-cols-5 xl:grid-cols-7 mx-auto border-b-2 pb-3 h-auto",
      style: {
        width: '90%'
      },
      children: categories.map(item => {
        return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: `py-3 ${item.const == selectedGroupId && 'border-b-4 border-yellow-400'}`,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            style: {
              minWidth: 100
            },
            className: `text-left pl-2 py-1 pr-2 border-r-2 cursor-pointer 
                                 ${item.const == selectedGroupId && selected}`,
            onMouseEnter: () => selectCategory(item.const),
            children: item.name
          })
        }, item.id);
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Cars["a" /* default */], {
      cars: selectedCars
    })]
  });
}
;
// EXTERNAL MODULE: ./helpers/consts.ts
var consts = __webpack_require__("LY/l");

// CONCATENATED MODULE: ./components/home/Review.tsx




function Review({
  data,
  index
}) {
  return !data ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {}) : /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `relative review-${index + 1} overflow-hidden cursor-pointer`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
      src: data.image || consts["a" /* NO_IMAGE */],
      loading: "lazy",
      className: `background-animate h-full w-full darken-image-80 hover-image ${!data.image && 'object-none'}`,
      alt: "image"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "text-shadow absolute bottom-5 text-white text-2xl font-bold w-full text-left px-4 two-liner",
      children: data.title
    })]
  }, data.id);
}
;
// CONCATENATED MODULE: ./components/home/Reviews.tsx


function Reviews({
  reviews
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "review-container px-8 pt-0 pb-5 w-full",
    children: reviews === null || reviews === void 0 ? void 0 : reviews.map((review, index) => {
      return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Review, {
        data: review,
        index: index
      }, review.id);
    })
  });
}
;
// CONCATENATED MODULE: ./components/home/Content.tsx




function Content({
  data,
  size = 'big'
}) {
  var _data$writer, _data$writer2;

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `flex flex-row my-4 overflow-hidden ${size == 'small' ? 'h-28' : 'h-64'}`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "overflow-hidden h-full",
      style: {
        width: size == 'small' ? 150 : '35%'
      },
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
        src: data.image || consts["a" /* NO_IMAGE */],
        className: "background-animate hover-image image-fit",
        width: 400,
        height: 300,
        layout: "responsive"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "flex-1 flex flex-col px-3",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: `h-auto two-liner font-bold ${size == 'small' ? 'text-md' : 'text-2xl'}`,
        children: data.title
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: `text-justify ${size == 'small' ? 'hidden' : 'my-3 four-liner h-2/5'}`,
        children: data.overview
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "h-1/5 flex flex-row justify-start",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "w-full flex-row flex gap-2 justify-start p-3",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: `w-8 ${size == 'small' && 'hidden'}`,
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
              src: (_data$writer = data.writer) === null || _data$writer === void 0 ? void 0 : _data$writer.photo,
              alt: "writer",
              className: "rounded-full w-7 h-7"
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "text-left",
            children: (_data$writer2 = data.writer) === null || _data$writer2 === void 0 ? void 0 : _data$writer2.name
          })]
        })
      })]
    })]
  });
}
;
// CONCATENATED MODULE: ./components/home/NewsAndTips.tsx



function NewsAndTips({
  newsTips
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "px-8",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "flex flex-row justify-around",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "font-bold text-2xl text-left w-3/5",
        children: "Latest News"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "font-bold text-2xl text-right w-4/5",
        children: "More"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "flex flex-row justify-around",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "w-full",
        children: newsTips === null || newsTips === void 0 ? void 0 : newsTips.map(item => {
          return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Content, {
            data: item
          }, item.id);
        })
      })
    })]
  });
}
;
// EXTERNAL MODULE: ./components/Car.tsx
var Car = __webpack_require__("ioxF");

// CONCATENATED MODULE: ./components/home/CarHighlight.tsx



function CarHighlight({
  title,
  cars
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "text-xl font-bold text-center p-1",
      children: title
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "flex flex-col gap-3",
      children: cars.map(item => {
        return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Car["a" /* default */], {
          car: item
        }, item.id);
      })
    })]
  });
}
;
// CONCATENATED MODULE: ./components/home/NewsAndPopularCars.tsx




function NewsAndPopularCars({
  newsTips,
  popularCars
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "flex flex-row",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "w-4/5",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(NewsAndTips, {
        newsTips: newsTips
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "w-1/5 px-4",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CarHighlight, {
        cars: popularCars === null || popularCars === void 0 ? void 0 : popularCars.slice(0, 6),
        title: "Most Popular"
      })
    })]
  });
}
;
// CONCATENATED MODULE: ./components/home/ContentHighlight.tsx




function ContentHighlight({
  title,
  contents
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "h-12 text-2xl font-bold border-b-2 border-gray-300 mb-4",
      children: title
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Review, {
        data: contents[0],
        index: 0
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      children: contents.map(item => {
        return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Content, {
          data: item,
          size: "small"
        }, item.id);
      })
    })]
  });
}
;
// CONCATENATED MODULE: ./components/home/NewsAndReviews.tsx



function NewsAndReviews({
  reviews,
  newsTips
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "flex flex-row gap-5 px-6",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "w-1/2",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(ContentHighlight, {
        title: "News",
        contents: newsTips.slice(0, 3)
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "w-1/2",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(ContentHighlight, {
        title: "Reviews",
        contents: reviews
      })
    })]
  });
}
;
// EXTERNAL MODULE: ./helpers/apollo.ts
var apollo = __webpack_require__("4JcU");

// EXTERNAL MODULE: ./helpers/queries/brandQuery.ts
var brandQuery = __webpack_require__("baw8");

// CONCATENATED MODULE: ./helpers/queries/contentQuery.ts
/* harmony default export */ var contentQuery = ({
  getContentByType: (type, count) => {
    return `query getContentByType {
                    contents (type :${type}, first: ${count}){
                        data{
                          id
                          title
                          overview
                          content
                          image
                          writer {        
                            name
                            photo
                          }
                          type
                        }
                    }
                }`;
  }
});
// CONCATENATED MODULE: ./pages/index.tsx















async function getStaticProps() {
  const {
    data: _brand
  } = await Object(apollo["b" /* fetchUsingGql */])(brandQuery["a" /* default */].getAll);
  const brands = _brand.brands;
  const {
    data: _car
  } = await Object(apollo["b" /* fetchUsingGql */])(carQuery["a" /* default */].getByGroup(), {
    group: "MOST_POPULAR"
  });
  const cars = _car.CarsByGroup;
  const {
    data: _review
  } = await Object(apollo["b" /* fetchUsingGql */])(contentQuery.getContentByType("REVIEW", 3));
  const reviews = _review.contents.data;
  const {
    data: _news
  } = await Object(apollo["b" /* fetchUsingGql */])(contentQuery.getContentByType("NEWS", 4));
  const newsTips = _news.contents.data;
  return {
    props: {
      brands,
      cars,
      reviews,
      newsTips
    } // will be passed to the page component as props

  };
}
function Home({
  brands,
  cars,
  reviews,
  newsTips,
  popularCars
}) {
  Object(external_react_["useEffect"])(() => console.log('rerender the page'));
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(head_default.a, {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
        children: "Autofun | Brands"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(ImageBannerWithSearchBar, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Spacer, {
      height: 100
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(BrandList["a" /* default */], {
      brands: brands
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(TopCar, {
      cars: cars
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Spacer, {
      height: 30
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Reviews, {
      reviews: reviews
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Spacer, {
      height: 30
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(NewsAndPopularCars, {
      newsTips: newsTips,
      popularCars: cars
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Spacer, {
      height: 50
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(NewsAndReviews, {
      reviews: reviews,
      newsTips: newsTips
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Spacer, {
      height: 50
    })]
  });
}

/***/ }),

/***/ 4:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("23aj");


/***/ }),

/***/ "4JcU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return client; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return fetchUsingGql; });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("z+8S");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);


const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__["ApolloClient"]({
  uri: 'https://backend.hadi-syahbal.com/graphql',
  cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__["InMemoryCache"]()
});
async function fetchUsingGql(query, variables = {}) {
  return client.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__["gql"]`${query}`,
    variables
  });
}

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "7UUK":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "8OQS":
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "ANQk":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "Aiso":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dQHF")


/***/ }),

/***/ "BwRl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SearchBar; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function SearchBar({
  border,
  shadow
}) {
  const style = {
    borderWidth: 4
  };
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: `${shadow} h-full w-full rounded-md overflow-hidden`,
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
      className: `${border} h-full flex flex-row w-full bg-white justify-around`,
      style: style,
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("input", {
        type: "text",
        className: "h-full p-2 rounded-sm w-4/5",
        placeholder: "Type Anything"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("button", {
        className: "bg-yellow-400 h-full w-1/5 text-white font-bold",
        style: {
          borderRadius: "5px 0px 0px 5px"
        },
        children: "Cari"
      })]
    })
  });
}
;

/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "LY/l":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return NO_IMAGE; });
const NO_IMAGE = '/images/image-placeholder.png';

/***/ }),

/***/ "OrhP":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);




const Menu = props => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: "h-full w-auto float-right inline",
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("ul", {
      className: "h-full inline-flex gap-3",
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("li", {
        className: "text-lg leading-10",
        children: "Beranda"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("li", {
        className: "text-lg leading-10",
        children: "Berita"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("li", {
        className: "text-lg leading-10",
        children: "Mobil"
      })]
    })
  });
};

/* harmony default export */ __webpack_exports__["a"] = (Menu);

/***/ }),

/***/ "TqRt":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "UlpK":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "ZKgy":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Cars; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Car__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("ioxF");



function Cars({
  cars,
  initialColCount = 5
}) {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: "p-7 overflow-hidden",
    style: {
      minHeight: 450
    },
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      className: `grid grid-cols-2 md:grid-cols-4 xl:grid-cols-${initialColCount} sm:grid-cols-3 gap-10`,
      children: cars === null || cars === void 0 ? void 0 : cars.map(car => {
        return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_Car__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"], {
          car: car
        }, car.id);
      })
    })
  });
}
;

/***/ }),

/***/ "aZWA":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  getByGroup: () => {
    return `query getByGroup($group: GroupType!){
                 CarsByGroup(group:$group){
                    id
                    name
                    image
                    min_price
                    max_price
                  }
            }`;
  },
  getByBrand: `
        query getByBrand ($brand_id: String) {
            cars ( brand_id: $brand_id) {
                data {
                  id
                  name
                  image
                  min_price
                  max_price
                  brand {
                    id
                    name
                    image
                    desc
                  }
                }
            }
        }
    `,
  getById: `
        query getById ($car_id: ID) {
            car ( id: $car_id) {                
              id
              name
              image
              min_price
              max_price
              built_year
              brand {
                id
                name
                image                    
              } 
              images {
                url               
              }
              body_type
              fuel
              transmission
              segmen
              power
            }
        }
    `
});

/***/ }),

/***/ "baw8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  getAll: `query getBrands {
                    brands {
                        id
                        name
                        image
                        desc
                    }
                }`
});

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cSw2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrandList; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);



function BrandList({
  brands,
  itemDirection = 'Horizontal',
  selectedId
}) {
  console.log('rerender brand list');
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_1__["useRouter"])();

  const goToCarList = brandId => {
    router.push('/brands/' + brandId);
  };

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: "w-full text-center",
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      className: "inline-block",
      style: {
        width: "95%"
      },
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
        className: `grid ${itemDirection == 'Horizontal' ? 'grid-cols-3 md:grid-cols-4 xl:grid-cols-8' : 'grid-cols-1'}  mx-auto`,
        children: brands === null || brands === void 0 ? void 0 : brands.map(brand => {
          return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
            className: `overflow-hidden w-full mx-auto p-3 ${selectedId == brand.id && 'rounded border-2'}`,
            style: {
              maxWidth: 100,
              height: 'auto'
            },
            children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
              className: "w-full text-center",
              children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("img", {
                src: brand.image,
                className: "hover-image background-animate inline-block",
                style: {
                  width: 60,
                  height: 60
                },
                onClick: () => goToCarList(brand.id),
                alt: ""
              })
            }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
              children: brand.name
            })]
          }, brand.id);
        })
      })
    })
  });
}
;

/***/ }),

/***/ "dQHF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__("8OQS"));

var _extends2 = _interopRequireDefault(__webpack_require__("pVnL"));

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _head = _interopRequireDefault(__webpack_require__("UlpK"));

var _toBase = __webpack_require__("7UUK");

var _imageConfig = __webpack_require__("ANQk");

var _useIntersection = __webpack_require__("vNVm");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default"} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const percentSizes = [...sizes.matchAll(/(^|\s)(1?\d?\d)vw/g)].map(m => parseInt(m[2]));

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (false) {}

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (false) {}
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (false) {}

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "ioxF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Car; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers_consts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("LY/l");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);





function Car({
  car
}) {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
    onClick: () => router.push('/cars/' + car.id),
    children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      style: {
        height: 120
      },
      className: "relative w-full overflow-hidden background-animate hover-image",
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("img", {
        src: car.image || _helpers_consts__WEBPACK_IMPORTED_MODULE_2__[/* NO_IMAGE */ "a"],
        className: "w-full h-full",
        loading: "lazy"
      })
    }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      className: "text-center font-semibold",
      children: car.name
    }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
      className: "text-center font-semibold text-yellow-500",
      style: {
        fontSize: 15
      },
      children: ["Rp.", car.min_price, " Juta ", car.max_price ? ' - Rp.' + car.max_price + ' Juta' : '']
    })]
  });
}
;

/***/ }),

/***/ "pVnL":
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "vNVm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__("cDcd");

var _requestIdleCallback = __webpack_require__("0G5g");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "z+8S":
/***/ (function(module, exports) {

module.exports = require("@apollo/client");

/***/ })

/******/ });