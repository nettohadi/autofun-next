module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cha2");


/***/ }),

/***/ "4JcU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return client; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return fetchUsingGql; });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("z+8S");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);


const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__["ApolloClient"]({
  uri: 'https://backend.hadi-syahbal.com/graphql',
  cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__["InMemoryCache"]()
});
async function fetchUsingGql(query, variables = {}) {
  return client.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__["gql"]`${query}`,
    variables
  });
}

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "BwRl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SearchBar; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function SearchBar({
  border,
  shadow
}) {
  const style = {
    borderWidth: 4
  };
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: `${shadow} h-full w-full rounded-md overflow-hidden`,
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
      className: `${border} h-full flex flex-row w-full bg-white justify-around`,
      style: style,
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("input", {
        type: "text",
        className: "h-full p-2 rounded-sm w-4/5",
        placeholder: "Type Anything"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("button", {
        className: "bg-yellow-400 h-full w-1/5 text-white font-bold",
        style: {
          borderRadius: "5px 0px 0px 5px"
        },
        children: "Cari"
      })]
    })
  });
}
;

/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "Lvc8":
/***/ (function(module, exports) {

module.exports = require("@apollo/client/react");

/***/ }),

/***/ "OrhP":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);




const Menu = props => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: "h-full w-auto float-right inline",
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("ul", {
      className: "h-full inline-flex gap-3",
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("li", {
        className: "text-lg leading-10",
        children: "Beranda"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("li", {
        className: "text-lg leading-10",
        children: "Berita"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("li", {
        className: "text-lg leading-10",
        children: "Mobil"
      })]
    })
  });
};

/* harmony default export */ __webpack_exports__["a"] = (Menu);

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cha2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "@apollo/client/react"
var react_ = __webpack_require__("Lvc8");

// EXTERNAL MODULE: ./helpers/apollo.ts
var apollo = __webpack_require__("4JcU");

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__("zPlV");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: ./components/SearchBar.tsx
var SearchBar = __webpack_require__("BwRl");

// EXTERNAL MODULE: ./components/Menu.tsx
var Menu = __webpack_require__("OrhP");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// CONCATENATED MODULE: ./components/Header.tsx







const Header = ({
  alwaysShow = false
}) => {
  const logo = 'https://www.autofun.co.id/dist/id/images/logo-id.4408ea.svg';
  const headerElement = Object(external_react_["useRef"])(null);
  const router = Object(router_["useRouter"])();
  Object(external_react_["useEffect"])(() => {
    if (router.route != '/') {
      var _headerElement$curren;

      (_headerElement$curren = headerElement.current) === null || _headerElement$curren === void 0 ? void 0 : _headerElement$curren.classList.remove('header-hidden');
      return;
    } else {
      var _headerElement$curren2;

      (_headerElement$curren2 = headerElement.current) === null || _headerElement$curren2 === void 0 ? void 0 : _headerElement$curren2.classList.add('header-hidden');
    }

    const handleScroll = () => {
      if (window.scrollY > 590) {
        var _headerElement$curren3;

        (_headerElement$curren3 = headerElement.current) === null || _headerElement$curren3 === void 0 ? void 0 : _headerElement$curren3.classList.remove('header-hidden');
      } else {
        var _headerElement$curren4;

        (_headerElement$curren4 = headerElement.current) === null || _headerElement$curren4 === void 0 ? void 0 : _headerElement$curren4.classList.add('header-hidden');
      }
    };

    window.addEventListener('scroll', handleScroll);
    console.log('attacth listener');
    return () => {
      console.log('remove listener');
      window.removeEventListener('scroll', handleScroll);
    };
  });
  console.log('rerender header');
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("header", {
    ref: headerElement,
    id: "header-nav",
    className: `fixed w-full bg-white z-10 header-nav`,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("nav", {
      className: "p-5 border-b-2",
      style: {
        height: 90
      },
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "flex flex-row h-full",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "w-1/5 h-full cursor-pointer",
          style: {
            minWidth: 200
          },
          onClick: () => router.push('/'),
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
            src: logo,
            className: "h-4/5"
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "flex-1 h-full w-3/5",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(SearchBar["a" /* default */], {
            border: "border-yellow-400"
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "flex-1 h-full w-1/5",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Menu["a" /* default */], {})
        })]
      })
    })
  });
};

/* harmony default export */ var components_Header = (Header);
// CONCATENATED MODULE: ./components/Footer.tsx


function Footer({
  cars
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "h-auto flex flex-row p-7 overflow-hidden",
    style: {
      background: '#282828'
    },
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "w-2/5",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "h-16 w-3/5 pr-4 mb-2",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
          className: "h-full w-full",
          src: "https://www.autofun.co.id/dist/id/images/logo-footer-id.b14c22.svg",
          loading: "lazy",
          alt: ""
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
        className: "text-gray-500 w-full",
        children: "Autofun.co.id adalah situs otomotif lengkap yang menyediakan berita mobil, ulasan, dengan sarana untuk membantu Anda membandingkan berbagai model. Semua yang Anda butuhkan untuk menemukan mobil sempurna ada di sini."
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "w-1/5",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-white font-bold mb-4",
        children: "Popular Cars"
      }), cars === null || cars === void 0 ? void 0 : cars.slice(0, 5).map(item => {
        return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "text-gray-500 mb-1",
          children: item === null || item === void 0 ? void 0 : item.name
        }, item.id);
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "w-1/5",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-white font-bold mb-4",
        children: "Berita & Ulasan"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-gray-500 mb-1",
        children: "Latest"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-gray-500 mb-1",
        children: "Reviews"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-gray-500 mb-1",
        children: "Guides"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-gray-500 mb-1",
        children: "Tips"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-gray-500 mb-1",
        children: "Owner Reviews"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "w-1/5"
    })]
  });
}
;
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// CONCATENATED MODULE: ./components/Layout.tsx






function Layout({
  children
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(head_default.a, {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("link", {
        rel: "shortcut icon",
        href: "/images/favicon-autofun.png"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(components_Header, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("main", {
      className: "main-content",
      children: children
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Footer, {
      cars: []
    })]
  });
}
;
// CONCATENATED MODULE: ./pages/_app.tsx


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Layout, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_["ApolloProvider"], {
      client: apollo["a" /* client */],
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Component, _objectSpread({}, pageProps))
    })
  });
}

/* harmony default export */ var _app = __webpack_exports__["default"] = (MyApp);

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "z+8S":
/***/ (function(module, exports) {

module.exports = require("@apollo/client");

/***/ }),

/***/ "zPlV":
/***/ (function(module, exports) {



/***/ })

/******/ });