import { ApolloClient, InMemoryCache } from '@apollo/client';
import { gql } from '@apollo/client';

export const client = new ApolloClient({
    uri: 'https://backend.hadi-syahbal.com/graphql',
    cache: new InMemoryCache()
});


export  async function fetchUsingGql(query, variables={}){
    return client.query({
        query: gql`${query}`, variables
    });

}



