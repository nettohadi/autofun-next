export default  {
    getAll : `query getBrands {
                    brands {
                        id
                        name
                        image
                        desc
                    }
                }`
}