module.exports = {
    images: {
        domains: ['images.autofun.co.id','www.autofun.co.id']
    }
}