webpackHotUpdate_N_E("pages/index",{

/***/ "./components/Car.tsx":
/*!****************************!*\
  !*** ./components/Car.tsx ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Car; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers_consts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../helpers/consts */ "./helpers/consts.ts");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "C:\\xampp\\htdocs\\autofun-next\\components\\Car.tsx",
    _s = $RefreshSig$();




function Car(_ref) {
  _s();

  var car = _ref.car;
  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    onClick: function onClick() {
      return router.push('/cars/' + car.id);
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      style: {
        height: 120
      },
      className: "relative w-full overflow-hidden background-animate p-3 hover-image",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: car.image || _helpers_consts__WEBPACK_IMPORTED_MODULE_2__["NO_IMAGE"],
        className: "w-full h-full",
        loading: "lazy"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "text-center font-semibold",
      children: car.name
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "text-center font-semibold text-yellow-500",
      style: {
        fontSize: 15
      },
      children: ["Rp.", car.min_price, " Juta ", car.max_price ? ' - Rp.' + car.max_price + ' Juta' : '']
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 9
  }, this);
}

_s(Car, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"]];
});

_c = Car;
;

var _c;

$RefreshReg$(_c, "Car");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9DYXIudHN4Il0sIm5hbWVzIjpbIkNhciIsImNhciIsInJvdXRlciIsInVzZVJvdXRlciIsInB1c2giLCJpZCIsImhlaWdodCIsImltYWdlIiwiTk9fSU1BR0UiLCJuYW1lIiwiZm9udFNpemUiLCJtaW5fcHJpY2UiLCJtYXhfcHJpY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUE7QUFFQTtBQUllLFNBQVNBLEdBQVQsT0FBMkI7QUFBQTs7QUFBQSxNQUFiQyxHQUFhLFFBQWJBLEdBQWE7QUFDdEMsTUFBTUMsTUFBTSxHQUFHQyw2REFBUyxFQUF4QjtBQUVBLHNCQUNJO0FBQUssV0FBTyxFQUFFO0FBQUEsYUFBTUQsTUFBTSxDQUFDRSxJQUFQLENBQVksV0FBV0gsR0FBRyxDQUFDSSxFQUEzQixDQUFOO0FBQUEsS0FBZDtBQUFBLDRCQUNJO0FBQUssV0FBSyxFQUFFO0FBQUNDLGNBQU0sRUFBQztBQUFSLE9BQVo7QUFDSyxlQUFTLEVBQUMsb0VBRGY7QUFBQSw2QkFJSTtBQUFLLFdBQUcsRUFBRUwsR0FBRyxDQUFDTSxLQUFKLElBQWFDLHdEQUF2QjtBQUFpQyxpQkFBUyxFQUFDLGVBQTNDO0FBQTJELGVBQU8sRUFBQztBQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLGVBT0k7QUFBSyxlQUFTLEVBQUMsMkJBQWY7QUFBQSxnQkFBNENQLEdBQUcsQ0FBQ1E7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVBKLGVBUUk7QUFBSyxlQUFTLEVBQUMsMkNBQWY7QUFBMkQsV0FBSyxFQUFFO0FBQUNDLGdCQUFRLEVBQUM7QUFBVixPQUFsRTtBQUFBLHdCQUNRVCxHQUFHLENBQUNVLFNBRFosWUFDNkJWLEdBQUcsQ0FBQ1csU0FBSixHQUFnQixXQUFXWCxHQUFHLENBQUNXLFNBQWYsR0FBMkIsT0FBM0MsR0FBcUQsRUFEbEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREo7QUFjSDs7R0FqQnVCWixHO1VBQ0xHLHFEOzs7S0FES0gsRztBQWlCdkIiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYjA2Y2RhMzJiNjliNWIxMTc0NWIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7Q2FyVHlwZX0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcbmltcG9ydCB7Tk9fSU1BR0V9IGZyb20gXCIuLi9oZWxwZXJzL2NvbnN0c1wiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSBcIm5leHQvaW1hZ2VcIjtcclxuaW1wb3J0IHt1c2VSb3V0ZXJ9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxudHlwZSBQcm9wcyA9IHsgY2FyOkNhclR5cGUgfTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhcih7Y2FyfTogUHJvcHMpIHtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBvbkNsaWNrPXsoKSA9PiByb3V0ZXIucHVzaCgnL2NhcnMvJyArIGNhci5pZCl9PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7aGVpZ2h0OjEyMH19XHJcbiAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBiYWNrZ3JvdW5kLWFuaW1hdGUgcC0zIGhvdmVyLWltYWdlXCI+XHJcbiAgICAgICAgICAgICAgICB7Lyo8SW1hZ2UgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgYm90dG9tLTAgdy1mdWxsXCIqL31cclxuICAgICAgICAgICAgICAgIHsvKiAgICAgICBvYmplY3RGaXQ9J2ZpbGwnIG9iamVjdFBvc2l0aW9uPXtcImNlbnRlclwifSBzcmM9e2Nhci5pbWFnZSB8fCBOT19JTUFHRX0gbGF5b3V0PVwiZmlsbFwiIC8+Ki99XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17Y2FyLmltYWdlIHx8IE5PX0lNQUdFfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsXCIgbG9hZGluZz1cImxhenlcIi8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtc2VtaWJvbGRcIj57Y2FyLm5hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1zZW1pYm9sZCB0ZXh0LXllbGxvdy01MDBcIiBzdHlsZT17e2ZvbnRTaXplOjE1fX0+XHJcbiAgICAgICAgICAgICAgICBScC57Y2FyLm1pbl9wcmljZX0gSnV0YSB7Y2FyLm1heF9wcmljZSA/ICcgLSBScC4nICsgY2FyLm1heF9wcmljZSArICcgSnV0YScgOiAnJ31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59OyJdLCJzb3VyY2VSb290IjoiIn0=