exports.ids = [9];
exports.modules = {

/***/ "5Q0L":
/***/ (function(module, exports) {



/***/ }),

/***/ "Fc8I":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ImageSlider; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("LE62");
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _splidejs_splide_dist_css_themes_splide_default_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("5Q0L");
/* harmony import */ var _splidejs_splide_dist_css_themes_splide_default_min_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_splidejs_splide_dist_css_themes_splide_default_min_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers_consts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("LY/l");





function ImageSlider({
  images,
  height
}) {
  const _images = images && images.length > 0 ? images : [{
    id: 1,
    url: _helpers_consts__WEBPACK_IMPORTED_MODULE_4__[/* NO_IMAGE */ "a"]
  }];

  if (!images) {
    return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      className: "flex justify-center align-middle",
      children: "Loading"
    });
  }

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: "w-full h-full overflow-hidden",
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__["Splide"], {
      options: {
        type: 'loop',
        perPage: 1,
        rewind: true,
        width: '100%',
        height: height,
        gap: '1rem'
      },
      children: _images === null || _images === void 0 ? void 0 : _images.map(item => {
        return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__["SplideSlide"], {
          children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("img", {
            src: item.url,
            loading: "lazy",
            alt: "",
            className: "w-full h-full"
          })
        }, item.id);
      })
    })
  });
}
;

/***/ })

};;