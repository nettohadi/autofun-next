exports.ids = [0];
exports.modules = {

/***/ "./components/ImageSlider.tsx":
/*!************************************!*\
  !*** ./components/ImageSlider.tsx ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ImageSlider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @splidejs/react-splide */ "@splidejs/react-splide");
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _splidejs_splide_dist_css_themes_splide_default_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @splidejs/splide/dist/css/themes/splide-default.min.css */ "./node_modules/@splidejs/splide/dist/css/themes/splide-default.min.css");
/* harmony import */ var _splidejs_splide_dist_css_themes_splide_default_min_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_splidejs_splide_dist_css_themes_splide_default_min_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers_consts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../helpers/consts */ "./helpers/consts.ts");

var _jsxFileName = "C:\\xampp\\htdocs\\autofun-next\\components\\ImageSlider.tsx";




function ImageSlider({
  images,
  height
}) {
  const _images = images && images.length > 0 ? images : [{
    id: 1,
    url: _helpers_consts__WEBPACK_IMPORTED_MODULE_4__["NO_IMAGE"]
  }];

  if (!images) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex justify-center align-middle",
      children: "Loading"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "w-full h-full overflow-hidden",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__["Splide"], {
      options: {
        type: 'loop',
        perPage: 1,
        rewind: true,
        width: '100%',
        height: height,
        gap: '1rem'
      },
      children: _images === null || _images === void 0 ? void 0 : _images.map(item => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__["SplideSlide"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: item.url,
            loading: "lazy",
            alt: "",
            className: "w-full h-full"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 36,
            columnNumber: 29
          }, this)
        }, item.id, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 25
        }, this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 13
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 9
  }, this);
}
;

/***/ }),

/***/ "./node_modules/@splidejs/splide/dist/css/themes/splide-default.min.css":
/*!******************************************************************************!*\
  !*** ./node_modules/@splidejs/splide/dist/css/themes/splide-default.min.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0ltYWdlU2xpZGVyLnRzeCJdLCJuYW1lcyI6WyJJbWFnZVNsaWRlciIsImltYWdlcyIsImhlaWdodCIsIl9pbWFnZXMiLCJsZW5ndGgiLCJpZCIsInVybCIsIk5PX0lNQUdFIiwidHlwZSIsInBlclBhZ2UiLCJyZXdpbmQiLCJ3aWR0aCIsImdhcCIsIm1hcCIsIml0ZW0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBUWUsU0FBU0EsV0FBVCxDQUFxQjtBQUFDQyxRQUFEO0FBQVNDO0FBQVQsQ0FBckIsRUFBOEM7QUFDekQsUUFBTUMsT0FBTyxHQUFHRixNQUFNLElBQUlBLE1BQU0sQ0FBQ0csTUFBUCxHQUFnQixDQUExQixHQUE4QkgsTUFBOUIsR0FBdUMsQ0FBQztBQUFDSSxNQUFFLEVBQUMsQ0FBSjtBQUFPQyxPQUFHLEVBQUVDLHdEQUFRQTtBQUFwQixHQUFELENBQXZEOztBQUNBLE1BQUcsQ0FBQ04sTUFBSixFQUFZO0FBQ1Isd0JBQ0k7QUFBSyxlQUFTLEVBQUMsa0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESjtBQUdIOztBQUNELHNCQUNJO0FBQUssYUFBUyxFQUFDLCtCQUFmO0FBQUEsMkJBQ0kscUVBQUMsNkRBQUQ7QUFDSSxhQUFPLEVBQUc7QUFDTk8sWUFBSSxFQUFFLE1BREE7QUFFTkMsZUFBTyxFQUFFLENBRkg7QUFHTkMsY0FBTSxFQUFHLElBSEg7QUFJTkMsYUFBSyxFQUFJLE1BSkg7QUFLTlQsY0FBTSxFQUFHQSxNQUxIO0FBTU5VLFdBQUcsRUFBTTtBQU5ILE9BRGQ7QUFBQSxnQkFXUVQsT0FYUixhQVdRQSxPQVhSLHVCQVdRQSxPQUFPLENBQUVVLEdBQVQsQ0FBY0MsSUFBRCxJQUFVO0FBQ25CLDRCQUNBLHFFQUFDLGtFQUFEO0FBQUEsaUNBQ0k7QUFBSyxlQUFHLEVBQUVBLElBQUksQ0FBQ1IsR0FBZjtBQUFvQixtQkFBTyxFQUFDLE1BQTVCO0FBQ0ssZUFBRyxFQUFDLEVBRFQ7QUFDWSxxQkFBUyxFQUFDO0FBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixXQUFrQlEsSUFBSSxDQUFDVCxFQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURBO0FBS0gsT0FORDtBQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREo7QUF3Qkg7QUFBQSxDIiwiZmlsZSI6IjAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQge1NwbGlkZSwgU3BsaWRlU2xpZGV9IGZyb20gJ0BzcGxpZGVqcy9yZWFjdC1zcGxpZGUnO1xyXG5pbXBvcnQgJ0BzcGxpZGVqcy9zcGxpZGUvZGlzdC9jc3MvdGhlbWVzL3NwbGlkZS1kZWZhdWx0Lm1pbi5jc3MnO1xyXG5pbXBvcnQge0ltYWdlVHlwZX0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcbmltcG9ydCB7Tk9fSU1BR0V9IGZyb20gXCIuLi9oZWxwZXJzL2NvbnN0c1wiO1xyXG5cclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgICBpbWFnZXM6IEltYWdlVHlwZVtdLFxyXG4gICAgaGVpZ2h0Om51bWJlclxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW1hZ2VTbGlkZXIoe2ltYWdlcywgaGVpZ2h0fTogUHJvcHMpIHtcclxuICAgIGNvbnN0IF9pbWFnZXMgPSBpbWFnZXMgJiYgaW1hZ2VzLmxlbmd0aCA+IDAgPyBpbWFnZXMgOiBbe2lkOjEsIHVybDogTk9fSU1BR0V9XTtcclxuICAgIGlmKCFpbWFnZXMpIHtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgYWxpZ24tbWlkZGxlXCI+TG9hZGluZzwvZGl2PlxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgPFNwbGlkZVxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17IHtcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnbG9vcCcsXHJcbiAgICAgICAgICAgICAgICAgICAgcGVyUGFnZTogMSxcclxuICAgICAgICAgICAgICAgICAgICByZXdpbmQgOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoICA6ICcxMDAlJyxcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQgOiBoZWlnaHQsXHJcbiAgICAgICAgICAgICAgICAgICAgZ2FwICAgIDogJzFyZW0nLFxyXG4gICAgICAgICAgICAgICAgfSB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBfaW1hZ2VzPy5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNwbGlkZVNsaWRlIGtleT17aXRlbS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17aXRlbS51cmx9IGxvYWRpbmc9XCJsYXp5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbFwiLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TcGxpZGVTbGlkZT4pXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9TcGxpZGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59OyJdLCJzb3VyY2VSb290IjoiIn0=